//
//  ViewController.swift
//  Test
//
//  Created by 范国徽 on 16/3/18.
//  Copyright © 2016年 范国徽. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    struct ViewControllerIdentifier {
        static let ScreenWidth = UIScreen.mainScreen().bounds.size.width
        static let ScreenHeight = UIScreen.mainScreen().bounds.size.height
        static let cellIdentifier = "cell"
    }
    var data: NSInteger = 20
    var tableView = UITableView(frame: CGRectMake(0, 64 , ViewControllerIdentifier.ScreenWidth , ViewControllerIdentifier.ScreenHeight), style: UITableViewStyle.Plain)
    func refreshData(){
        let time = dispatch_time(DISPATCH_TIME_NOW, Int64(1 * NSEC_PER_SEC))
        dispatch_after(time, dispatch_get_main_queue(), { () -> Void in
            self.data = 20
            self.tableView.endRefreshing()
            self.tableView.reloadData()
        })
    }
    func loadMore(){
        let time = dispatch_time(DISPATCH_TIME_NOW, Int64(1 * NSEC_PER_SEC))
        dispatch_after(time, dispatch_get_main_queue(), { () -> Void in
            self.data += 20
            self.tableView.reloadData()
            self.tableView.endLoadMore()
            
        })
    }
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data
    }
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCellWithIdentifier(ViewControllerIdentifier.cellIdentifier)
        if var _ = cell {
      
        }else {
                cell = UITableViewCell(style: UITableViewCellStyle.Default, reuseIdentifier: ViewControllerIdentifier.cellIdentifier)
        }
        cell?.textLabel?.text = "\(indexPath.row)-HeavenGifts 一家专门买电子烟的网站！"
        
        return cell!
    }
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        self.tableView.startRefreshing()
    }
    let refresh = HGPullToRefresh()
    let loadMoreView =  PullToLoadMore(frame: CGRectZero)
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = UIColor.groupTableViewBackgroundColor()
        

        self.tableView.addPullToRefresh(refresh) {
            self.refreshData()
        }
        self.tableView.addRefreshFooter(loadMoreView) { () -> () in
            self.loadMore()
        }
        view.addSubview(self.tableView)

        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

