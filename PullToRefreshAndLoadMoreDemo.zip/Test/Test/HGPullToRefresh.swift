//
//  HGPullToRefresh.swift
//  hg_ios_swift
//
//  Created by 范国徽 on 16/3/16.
//  Copyright © 2016年 范国徽. All rights reserved.
//

import UIKit
 public class HGPullToRefresh: PullToRefresh {
     public convenience init() {
        
    let refreshView = HGHeaderRefreshView(frame:CGRectMake(0,0 , UIScreen.mainScreen().bounds.size.width,60))
        let animator = HGRefreshViewAnimator(refreshView: refreshView)
        self.init(refreshView: refreshView, animator: animator)
    }
    
    
}

class CircleImageView: UIImageView {
   
    override func layoutSubviews() {
        super.layoutSubviews()
        
        initLayer()
    }
   private var shapeLayer = CAShapeLayer()
    func initLayer(){
        
      let layer = CALayer()
      shapeLayer.fillColor = UIColor.clearColor().CGColor
      shapeLayer.lineWidth = CircleImageViewIdentifier.CircleImageViewLineWidth
      shapeLayer.strokeColor = HGHeaderRefreshView.HGHeaderRefreshViewIdentifier.textColor.CGColor
      shapeLayer.strokeStart = 0
      shapeLayer.strokeEnd = 1
      shapeLayer.position = self.center
      shapeLayer.frame = CGRectMake(0, 0, CircleImageViewIdentifier.CircleImageViewRadius, CircleImageViewIdentifier.CircleImageViewRadius)
      let radius = CircleImageViewIdentifier.CircleImageViewRadius - CircleImageViewIdentifier.CircleImageViewLineWidth ;
      let path = UIBezierPath(arcCenter: self.center, radius: radius, startAngle: 0, endAngle: 0, clockwise: true)
      shapeLayer.path = path.CGPath ;
      layer.addSublayer(shapeLayer)
      self.layer.addSublayer(layer)
    
      
    }

    
    
    
    var progress: CGFloat = 0 {
        
        willSet{
            let value = newValue > 1 ? 1 : newValue ;
           let endAngle =   2 * CGFloat( M_PI ) * value
           shapeLayer.path = UIBezierPath(arcCenter:CGPointMake(self.bounds.width/2, self.bounds.width/2), radius: (CircleImageViewIdentifier.CircleImageViewRadius - CircleImageViewIdentifier.CircleImageViewLineWidth) , startAngle: 0, endAngle: endAngle, clockwise: true).CGPath
        }
    
    }
    func initLayout() {
       shapeLayer.hidden = false
       self.image = UIImage(named: "down")
    }
    func release(progress: CGFloat) {
        self.progress = progress
        if progress >= 1 {
            UIView.animateWithDuration(1, animations: { () -> Void in
                
                self.image = UIImage(named: "up")
                
                }, completion: { (finish: Bool)  -> Void in
                   
     
            })
        }else {
            UIView.animateWithDuration(1, animations: { () -> Void in
                
                self.image = UIImage(named: "down")
                
                }, completion: { (finish: Bool) -> Void in
                    
            })
        }
    }
  
    func stopTheAnimator(){
        shapeLayer.hidden = true
        self.layer.removeAllAnimations()
        self.image = UIImage(named: "down")
    }
    func  loadingAnimation() {
   
      self.shapeLayer.hidden = true
  
      let after = dispatch_time(DISPATCH_TIME_NOW, 1)
        dispatch_after(after, dispatch_get_main_queue()) { () -> Void in
            self.image = UIImage(named: "loading_indicator");
            let basicAnimation = CABasicAnimation()
            basicAnimation.keyPath = "transform.rotation.z"
            basicAnimation.fromValue = 0
            basicAnimation.toValue = M_PI * 2
            basicAnimation.duration = 1.0
            basicAnimation.repeatCount = FLT_MAX
            self.layer.addAnimation(basicAnimation, forKey:nil)
        }
        

        
        
        
    }
    
    struct CircleImageViewIdentifier {
        static let CircleImageViewRadius : CGFloat =  14
        static let CircleImageViewLineWidth: CGFloat = 1
    }
 
}

class HGHeaderRefreshView: UIView {
   private let nameLabel = UILabel()
   private let imgView = CircleImageView()

    override init(frame: CGRect) {
    super.init(frame: frame)
        
     initView()
    }
    func initView(){
        
        nameLabel.textAlignment = NSTextAlignment.Center
        nameLabel.font = HGHeaderRefreshViewIdentifier.textFont
        nameLabel.text = "下拉刷新"
        nameLabel.textColor = HGHeaderRefreshViewIdentifier.textColor
        nameLabel.center = self.center
        imgView.image = UIImage(named: "down")
        imgView.bounds = CGRectMake(0, 0, 30, 30)
        let attributes = [NSFontAttributeName:nameLabel.font]
        let size = "下拉刷新".sizeWithAttributes(attributes)
        nameLabel.bounds = CGRectMake(0, 0, size.width, size.height)
        
        var imgViewCenter: CGPoint = self.center
        imgViewCenter.x = (imgViewCenter.x - size.width/2 - CircleImageView.CircleImageViewIdentifier.CircleImageViewRadius - 10)
        imgView.center  = imgViewCenter

        
    }
    override func layoutSubviews() {
        self.addSubview(nameLabel)
        self.addSubview(imgView)
    }
    func setNameString(name: String) {
        if nameLabel.text == name {
            return
        }
        nameLabel.text = name
        
    }
    
    struct HGHeaderRefreshViewIdentifier {
        static let refreshViewWidth:CGFloat = UIScreen.mainScreen().bounds.size.width
        static let imgViewWidth: CGFloat = 30
        static let textFont = UIFont.systemFontOfSize(12)
        static let textColor = UIColor(red: 120.0/255, green: 120.0/255, blue: 120.0/255.0, alpha: 1.0)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

class HGRefreshViewAnimator: NSObject, RefreshViewAnimator {
    let refreshView: HGHeaderRefreshView
    let refreshViewHeight: CGFloat
    
    init(refreshView: HGHeaderRefreshView) {
        self.refreshView = refreshView
        self.refreshViewHeight = refreshView.frame.size.height
    }
    
    func animateState(state: State) {
        switch state {
        case .Inital :
            initLayout()
        case .Releasing(let progress) :
           releaseAnimator(progress)
        case .Loading :
            loadTheView()
        case .Finished :
            stopTheAnimator()
            
        }
    }
    func initLayout() {
        refreshView.setNameString("下拉刷新")
        refreshView.imgView.initLayout()
    }
    func releaseAnimator(prgress: CGFloat) {
        if prgress >= 1.0 {
            refreshView.setNameString("释放刷新")
        }
        else {
            refreshView.setNameString("下拉刷新")
        }
       refreshView.imgView.release(prgress)
 
    }
    func loadTheView() {
        refreshView.setNameString("正在加载")
        refreshView.imgView.loadingAnimation()

    }
    func stopTheAnimator(){
        refreshView.setNameString("下拉刷新")
        refreshView.imgView.stopTheAnimator()
    }
    
    
    
}


