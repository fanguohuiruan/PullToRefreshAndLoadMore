//
//  PullToLoadMore.swift
//  hg_ios_swift
//
//  Created by 范国徽 on 16/3/17.
//  Copyright © 2016年 范国徽. All rights reserved.
//

import UIKit
public class PullToLoadMore: UIView {

    struct ScrollViewContentIdentifier {
        static let scrollViewContentOffSetOberverIdentifier  = "scrollView.contentOffset"
        static let scrollViewContentSizeObserverIdentifier   = "scrollView.contentSize"
        static let loadMoreViewFooterHeight:CGFloat = 60
        static let loadMoreViewWidth:CGFloat = UIScreen.mainScreen().bounds.size.width
        static let textFont = UIFont.systemFontOfSize(12)
        static let textColor = UIColor(red: 120.0/255, green: 120.0/255, blue: 120.0/255.0, alpha: 1.0)
    }
    // UILabel
    
    let statusLab = UILabel()
    
    //UIImageView
    
    let arrowImage = UIImageView()
    
    // UIAcitivityIndicatorView
    
    let indicatorView = UIActivityIndicatorView()
    
    var stateTextDic = ["normalText"  : "上拉加载",
        "pullingText" : "释放加载",
        "loadingText" : "加载中"
    ]
    
    var autoLoadMore:Bool =  true {
        didSet{
            if autoLoadMore {
                arrowImage.removeFromSuperview()
                arrowImage.image = nil
                self.stateTextDic = ["normalText"  : "加载中",
                    "pullingText" : "加载中",
                    "loadingText" : "加载中",
                    "nomoreData"  : "No more content available"
                ]
            }else {
                arrowImage.removeFromSuperview()
                self.addSubview(self.arrowImage)
                self.arrowImage.image = UIImage(named: "up")
                self.arrowImage.image = nil
                self.stateTextDic = ["normalText"  : "上拉加载",
                    "pullingText" : "释放加载",
                    "loadingText" : "加载中" ,
                    "nomoreData"  : "No more content available"

                ]
            }
        }
    }
    var loadMoreEnable:Bool = true {
        didSet{
            if loadMoreEnable {
                self.removeFromSuperview()
                self.scrolloView?.addSubview(self)
            }else {
                self.removeFromSuperview()
            }
        }
    }
    var noMoreData: Bool = false {
      
        didSet{
            if noMoreData {
                self.refreshState = .NoMoreData
            }else {
                self.refreshState = .Nomal
            }
        }
    }
    var action: (() -> ())?

    var dragHeight:CGFloat  {
        set {
            self.dragHeight = newValue
        }
        get {
            let contentHeight = self.scrolloView?.contentSize.height
            let tableViewHeight = self.scrolloView?.bounds.size.height
            let originalY = CGFloat(max(Float(contentHeight!), Float(tableViewHeight!)))
        
            return  ((self.scrolloView?.contentOffset.y)! + (self.scrolloView?.bounds.size.height)! - originalY - self.initEdgeInset.bottom )
        }
    }
  
    
    var initEdgeInset: UIEdgeInsets = UIEdgeInsetsZero
    var drageHeightThreshold: CGFloat = CGFloat(60)
    var refreshState:RefreshState = .Nomal{
        didSet{
            switch refreshState {
            case .Nomal :
                normalAnimation()
                UIView.animateWithDuration(0.3, animations: { () -> Void in
                    self.scrolloView?.contentInset = self.initEdgeInset
                })
                break
            case .Pulling :
                 pullingAnimation()
                break
            case .Loading :
                loadingAnimation()
                UIView.animateWithDuration(0.3, animations: { () -> Void in
                    var inset = self.scrolloView?.contentInset
                     inset?.bottom += ScrollViewContentIdentifier.loadMoreViewFooterHeight
                     self.scrolloView?.contentInset  = inset!
                })
                    action?()
                break
            case .NoMoreData :
                noMoreDataAnimation()
                break
                
            }
        }
    }
    
    
   
    
    var scrolloView: UIScrollView? {
        didSet{
          initEdgeInset = (scrolloView?.contentInset)!
          scrolloView?.addSubview(self)
          addScrollViewObserver()
          refreshTheFooterFrame()
        }
    }
    
    public enum RefreshState{
        case Nomal, Pulling, Loading , NoMoreData
        
    }
    deinit{
           removeScrollViewObserver()
    }
    public override func layoutSubviews() {
        super.layoutSubviews()

    
    }
    override init(frame: CGRect) {
        super.init(frame: frame)

        self.drawRefreshView()
        self.addSubview(statusLab)
        self.addSubview(arrowImage)
        self.addSubview(indicatorView)
    }

    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
   
   
    func drawRefreshView(){
       self.frame = CGRectMake(0, 0, ScrollViewContentIdentifier.loadMoreViewWidth, ScrollViewContentIdentifier.loadMoreViewFooterHeight)
       statusLab.frame = CGRectMake(0, 0, ScrollViewContentIdentifier.loadMoreViewWidth, ScrollViewContentIdentifier.loadMoreViewFooterHeight)
       statusLab.font = ScrollViewContentIdentifier.textFont
       statusLab.textColor = ScrollViewContentIdentifier.textColor
       statusLab.backgroundColor = UIColor.clearColor()
       statusLab.textAlignment = .Center
      
        arrowImage.image = UIImage(named: "down")
        arrowImage.frame = CGRectMake(ScrollViewContentIdentifier.loadMoreViewWidth/2 - 60, (ScrollViewContentIdentifier.loadMoreViewFooterHeight - 32)/2 , 32, 32)
        
        indicatorView.activityIndicatorViewStyle = .Gray
        indicatorView.color = ScrollViewContentIdentifier.textColor
        indicatorView.frame = arrowImage.frame
        indicatorView.hidesWhenStopped = true
      
        
        
    }
    func refreshTheFooterFrame(){
        var frame = self.frame
        frame.origin.y = CGFloat(max(Float((scrolloView?.frame.size.height)!), Float((self.scrolloView?.contentSize.height)!)))
        self.frame = frame
    }
    
    func addScrollViewObserver(){
        scrolloView?.addObserver(self, forKeyPath: "contentOffset", options: NSKeyValueObservingOptions.Initial, context: nil)
        scrolloView?.addObserver(self, forKeyPath: "contentSize", options: .Initial, context: nil)
    }
    func removeScrollViewObserver(){
        scrolloView?.removeObserver(self, forKeyPath: ScrollViewContentIdentifier.scrollViewContentOffSetOberverIdentifier)
        scrolloView?.removeObserver(self, forKeyPath: ScrollViewContentIdentifier.scrollViewContentSizeObserverIdentifier)
    }
    override public func observeValueForKeyPath(keyPath: String?, ofObject object: AnyObject?, change: [String : AnyObject]?, context: UnsafeMutablePointer<Void>) {
        if let pathValue = keyPath {
            switch pathValue {
                case "contentOffset" :
                    scrollViewContentOffsetChanged()
                break
                case "contentSize" :
                    scrollViewContentSizeChanged()
                break
                default: break
            }
        }
       
    }
    func scrollViewContentOffsetChanged() {
        if ((self.dragHeight < 0) || (refreshState == .Loading) || !loadMoreEnable) {
//            print("dragHeight \(self.dragHeight)")
            return
        }
        if self.refreshState == .NoMoreData {
            return ;
        }
        
        if self.autoLoadMore == true {
            
            if self.dragHeight > 1 {
                self.refreshState = RefreshState.Loading
            }
            
        }else {
            if (self.scrolloView?.dragging) == true {
                if self.dragHeight < self.drageHeightThreshold {
                    self.refreshState = .Nomal
                }else {
                    self.refreshState = .Pulling
                }
            }else {
               
                
                if self.refreshState == .Pulling {
                    self.refreshState = .Loading
                }
                
            }
            
        }
        
        
        
    }
    func scrollViewContentSizeChanged() {
       
        refreshTheFooterFrame()
    }
    
    func normalAnimation() {
        statusLab.text = stateTextDic["normalText"]
        arrowImage.hidden = false
        indicatorView.stopAnimating()
        UIView.animateWithDuration(0.3) { () -> Void in
            self.arrowImage.transform = CGAffineTransformMakeRotation(CGFloat(M_PI))
        }
        
    }
    func pullingAnimation() {
        statusLab.text = self.stateTextDic["pullingText"]
        UIView.animateWithDuration(0.3) { () -> Void in
            self.arrowImage.transform = CGAffineTransformIdentity
        }
    }
    func loadingAnimation() {
       self.statusLab.text = self.stateTextDic["loadingText"]
        self.arrowImage.hidden = true
        self.arrowImage.transform = CGAffineTransformMakeRotation(CGFloat(M_PI))
        self.indicatorView.startAnimating()
    }
    func noMoreDataAnimation(){
      
        self.statusLab.text = self.stateTextDic["nomoreData"]
        indicatorView.stopAnimating()
        self.arrowImage.hidden = true
        
    }
    func endRefresh() {
        self.refreshState = .Nomal
        
    }
    
    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
    }
    */

}
