//
//  UIScrollView + PullToLoadMore.swift
//  hg_ios_swift
//
//  Created by 范国徽 on 16/3/17.
//  Copyright © 2016年 范国徽. All rights reserved.
//

import UIKit
private var associatedObjectHandle: UInt8 = 0

extension UIScrollView {
    
    private(set) var pullLoadMore: PullToLoadMore? {
        get {
            return objc_getAssociatedObject(self, &associatedObjectHandle) as? PullToLoadMore
        }
        set {
            objc_setAssociatedObject(self, &associatedObjectHandle, newValue, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        }
    }
    
    
    func addRefreshFooter(pullToLoadMoreView: PullToLoadMore , handle:() -> ()) -> PullToLoadMore{
        self.pullLoadMore = pullToLoadMoreView
        pullToLoadMoreView.action = handle
        pullToLoadMoreView.scrolloView = self
        return pullToLoadMoreView
    }
    
    func startLoadMore() {
       pullLoadMore?.scrolloView?.startLoadMore()
    }
    
    func endLoadMore() {
        pullLoadMore?.scrolloView?.endRefreshing()
    }

}
